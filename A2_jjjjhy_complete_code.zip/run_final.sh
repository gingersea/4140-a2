#!/usr/bin/env bash
set -euo pipefail

# Run the November 4 commands from the directory containing the course data.
if [[ -e submission.csv ]]; then
    echo "Use a fresh working directory to preserve the existing submission.csv." >&2
    exit 1
fi
sha256sum --check <<'DIGESTS'
01deb0cab0a0b5344a0a6680f00762f213558459b51c78d411c7d349b1d85162  data/train.fasta
65351015f4c741a246f43dbebd4a5cfa0a4467b8efa6e7b8ca15392120009300  data/val.fasta
653b8c29c14e993700d9b01438c58650983b1dcd3ff450a013ed055d61000e2c  data/test.fasta
DIGESTS

small=models/esm2_t33_650M_UR50D
large=models/esm2_t36_3B_UR50D
if [[ ! -s "$small/model.safetensors" || ! -s "$small/config.json" || ! -s "$small/vocab.txt" || ! -s "$small/tokenizer_config.json" || ! -s "$small/special_tokens_map.json" ]]; then
    python3 download_esm.py
fi

mkdir -p "$large"
if [[ ! -s "$large/config.json" ]]; then
    curl -fLsS --retry 5 --retry-delay 5 --max-time 60 \
        https://hf-mirror.com/facebook/esm2_t36_3B_UR50D/resolve/main/config.json \
        -o "$large/config.json"
fi
have_archived_shards() {
    [[ $(stat -Lc %s "$large/pytorch_model-00001-of-00002.bin" 2>/dev/null || true) == 9976735419 &&
       $(stat -Lc %s "$large/pytorch_model-00002-of-00002.bin" 2>/dev/null || true) == 1390347055 &&
       -s "$large/pytorch_model.bin.index.json" ]]
}
if ! have_archived_shards; then
    shard_script="$PWD/dl.sh"
    (cd "$large" && bash "$shard_script")
    if ! have_archived_shards; then
        echo "The archived 3B weight download is incomplete." >&2
        exit 1
    fi
fi
for name in vocab.txt tokenizer_config.json special_tokens_map.json; do
    if [[ ! -s "$large/$name" ]]; then
        cp "$small/$name" "$large/$name"
    fi
done

python3 esm_embed.py embed
python3 esm3b_embed.py
python3 final_probes.py
