#!/bin/bash
# download the two weight shards sequentially in background
for f in pytorch_model-00001-of-00002.bin pytorch_model-00002-of-00002.bin pytorch_model.bin.index.json; do
  echo "downloading $f ..."
  env -i HOME="$HOME" PATH="$PATH" curl -sL --retry 10 --retry-delay 10 --retry-all-errors -C - --max-time 3600 "https://hf-mirror.com/facebook/esm2_t36_3B_UR50D/resolve/main/$f" -o $f
  echo "$f done: $(ls -la $f 2>/dev/null | awk '{print $5}')"
done
