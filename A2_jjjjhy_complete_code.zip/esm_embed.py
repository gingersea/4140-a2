import os
import sys

os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

import numpy as np
import torch
from transformers import EsmModel, EsmTokenizer

MODEL_DIR = "models/esm2_t33_650M_UR50D"
EMB_DIR = "data/emb"
MAXLEN = 1022  # ESM2 650M max positions - 2


def read_fasta(path):
    seqs, ids = [], []
    cur_h, cur_s = None, []
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if cur_h is not None:
                    seqs.append("".join(cur_s)); ids.append(cur_h)
                cur_h = line; cur_s = []
            elif line.strip():
                cur_s.append(line.strip())
    if cur_h is not None:
        seqs.append("".join(cur_s)); ids.append(cur_h)
    return ids, seqs


def extract(paths, tag):
    tok = EsmTokenizer.from_pretrained(MODEL_DIR)
    model = EsmModel.from_pretrained(MODEL_DIR, torch_dtype=torch.float16)
    model = model.cuda().eval()
    if torch.cuda.device_count() > 1:
        model = torch.nn.DataParallel(model)

    ids_all, seqs_all = [], []
    for p in paths:
        i, s = read_fasta(p)
        ids_all += i; seqs_all += s

    bs = 16
    embeds = np.zeros((len(seqs_all), model.module.config.hidden_size
                       if isinstance(model, torch.nn.DataParallel)
                       else model.config.hidden_size), dtype=np.float32)
    with torch.no_grad():
        for start in range(0, len(seqs_all), bs):
            batch = seqs_all[start:start + bs]
            enc = tok(batch, return_tensors="pt", padding=True,
                      truncation=True, max_length=MAXLEN)
            enc = {k: v.cuda() for k, v in enc.items()}
            out = model(**enc).last_hidden_state  # (B, L, D)
            mask = enc["attention_mask"].unsqueeze(-1).float()
            mean = (out * mask).sum(1) / mask.sum(1)
            embeds[start:start + bs] = mean.cpu().numpy()
            if (start // bs) % 50 == 0:
                print(f"  {tag}: {start}/{len(seqs_all)}", flush=True)

    np.save(os.path.join(EMB_DIR, f"emb_{tag}.npy"), embeds)
    with open(os.path.join(EMB_DIR, f"ids_{tag}.txt"), "w") as f:
        f.write("\n".join(i[1:] for i in ids_all))
    print(f"saved {tag}: {embeds.shape}")




if __name__ == "__main__":
    os.makedirs(EMB_DIR, exist_ok=True)
    cmd = sys.argv[1]
    if cmd == "embed":
        extract(["data/train.fasta"], "train")
        extract(["data/val.fasta"], "val")
        extract(["data/test.fasta"], "test")
