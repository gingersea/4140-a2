"""Replay the archived A2 final step on the November 4 competition embeddings.

Run in an empty working directory containing data/emb with the archived inputs.
The input and output checks were added when exporting the original inline
Python command. The text between the two markers is the command body.
"""

from hashlib import sha256
from pathlib import Path


def file_digest(path):
    digest = sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


archive_digests = {
    "emb_train.npy": "9ed53f224866886cf2260a36a9a283cbd6fb0e6fc14ca1c7201876ff0a05cbf8",
    "emb_test.npy": "5d63831c86e274b42ba479a688c90c2a0c6975db83251e270ef417fe33eab70a",
    "emb3b_train.npy": "31bc3fefbc2ad78b2799b847abaa0f5e49dc2956074b59713fef256268375229",
    "emb3b_test.npy": "d78c87bcac114a1af0bead3e87a22d1b50b8f4b5937561db28ee532fca8a6748",
    "ids_train.txt": "9af131ac8471e82c2e332ffae9df04206588b47abea8724474c0e0d3abe2a784",
    "ids3b_train.txt": "9af131ac8471e82c2e332ffae9df04206588b47abea8724474c0e0d3abe2a784",
    "ids_test.txt": "942d77db8381a6dd705d18b82b63555c1d79558baa4559908341d0b89162c1f7",
}

if Path("submission.csv").exists():
    raise SystemExit("Use a fresh working directory to preserve the archived submission.csv.")
for filename, expected in archive_digests.items():
    path = Path("data/emb") / filename
    if not path.is_file() or file_digest(path) != expected:
        raise SystemExit(f"Missing or different November 4 benchmark input: {path}")

# BEGIN original inline Python

import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression

M = {'aminoglycoside':0,'macrolide-lincosamide-streptogramin':1,'polymyxin':2,
'fosfomycin':3,'trimethoprim':4,'bacitracin':5,'quinolone':6,'multidrug':7,
'chloramphenicol':8,'tetracycline':9,'rifampin':10,'beta_lactam':11,
'sulfonamide':12,'glycopeptide':13}
def labels_from_ids(ids_txt):
    y=[]
    for h in open(ids_txt):
        h=h.strip()
        y.append(M[h.split('|')[3]] if '|FEATURES|' in h else 14)
    return np.array(y)

y_tr = labels_from_ids('data/emb/ids_train.txt')
y_tr3 = labels_from_ids('data/emb/ids3b_train.txt')
assert (y_tr==y_tr3).all()

# 650M
X_tr = np.load('data/emb/emb_train.npy'); X_te = np.load('data/emb/emb_test.npy')
mu, sd = X_tr.mean(0), X_tr.std(0)+1e-6
X_tr=(X_tr-mu)/sd; X_te=(X_te-mu)/sd
w = dict(enumerate(len(y_tr)/(15*np.bincount(y_tr,minlength=15))))
clf650 = LogisticRegression(C=0.3, max_iter=3000, solver='lbfgs', class_weight=w).fit(X_tr, y_tr)
p650 = clf650.predict_proba(X_te)

# 3B
X_tr3 = np.load('data/emb/emb3b_train.npy'); X_te3 = np.load('data/emb/emb3b_test.npy')
mu3, sd3 = X_tr3.mean(0), X_tr3.std(0)+1e-6
X_tr3=(X_tr3-mu3)/sd3; X_te3=(X_te3-mu3)/sd3
clf3b = LogisticRegression(C=0.1, max_iter=3000, solver='lbfgs', class_weight=w).fit(X_tr3, y_tr)
p3b = clf3b.predict_proba(X_te3)

ens = p650 + p3b  # 1:1
pred = ens.argmax(1)
ids = open('data/emb/ids_test.txt').read().split('\n')
pd.DataFrame({'id': ids, 'label': pred}).to_csv('submission.csv', index=False)
from collections import Counter
print('test dist:', dict(sorted(Counter(pred).items())))
print('saved submission.csv')
# END original inline Python

expected_submission = "6e7203aa7c9bf4bedbd4ffacdbbe603eb7ca0bdea99f0dc5e49a8d44f6e63b33"
if file_digest("submission.csv") != expected_submission:
    raise SystemExit("The generated CSV differs from the November 4 archive.")
print("Verified: submission.csv matches the archived file byte for byte.")
